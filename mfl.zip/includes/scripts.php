<!-- jquery -->
<script src="assets/js/jquery.js"></script>
<!-- bootstrap js -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- swipper js -->
<script src="assets/js/swiper.min.js"></script>
<!-- lightcase js-->
<script src="assets/js/lightcase.js"></script>
<!-- odometer js -->
<script src="assets/js/odometer.min.js"></script>
<!-- viewport js -->
<script src="assets/js/viewport.jquery.js"></script>
<!-- progress js -->
<script src="assets/js/circle-progress.min.js"></script>
<!-- aos js file -->
<script src="assets/js/aos.js"></script>
<!-- nice select js -->
<script src="assets/js/jquery.nice-select.js"></script>
<!-- paroller js -->
<script src="assets/js/jquery.paroller.min.js"></script>
<!-- flipclock js -->
<script src="assets/js/flipclock.min.js"></script>
<!-- countdown js -->
<script src="assets/js/jquery.countdown.min.js"></script>
<!-- easypiechart js -->
<script src="assets/js/jquery.easypiechart.js"></script>
<!-- isotope js -->
<script src="assets/js/isotope.pkgd.min.js"></script>
<!-- preloader js -->
<script src="assets/js/preloader.js"></script>
<!-- main -->
<script src="assets/js/main.js"></script>