<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Contacto';
$contacto = 'active';
include('includes/head.php');
?>

<body >
    <?php
        include('includes/header2.php');
        include('includes/preloader.php');
        include('modules/contacto.php');
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>

</body>

</html>