<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Nosotros';
$nosotros = 'active';
include('includes/head.php');
?>

<body >
    <?php
        include('includes/header2.php');
        include('includes/preloader.php');
        include('modules/nosotros.php');
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>

</body>

</html>