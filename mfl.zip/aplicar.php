<!DOCTYPE html>
<html lang="en">
<?php
$title = 'Aplicar';
$aplicar = 'active';
include('includes/head.php');
?>

<body >
    <?php
        include('includes/header2.php');
        include('includes/preloader.php');
        include('modules/aplicar.php');
        include('includes/footer.php');
        include('includes/scripts.php');
    ?>

</body>

</html>